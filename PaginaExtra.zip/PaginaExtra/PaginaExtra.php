<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ENKOR-TECH</title>
    <meta name="ENKOR" content="Página oficial de empresa de refrigeración ENKOR-TECH">
    <link rel="stylesheet" href="../main.css">
    <link rel="stylesheet" href="extra.css">
    <link rel="icon" href="../imagenes/iconos/logo%20icono.png">
</head>

<body>
    <nav>
        <a href="../index.html" style="float: left; width: 200px;"><img id="logoNav" src="../imagenes/logos/ENKOR-TECH-LOGOTIPODIGITAL-01.png"></a>
        <a href="../index.html" style="float: left; width: 200px;"><img id="logoNavEscondido" src="../imagenes/logos/ENKOR-TECH-LOGOTIPODIGITAL-02TR.png"></a>
        <div id="divNav">
            <div class="elNav invisibleCelular"><a href="../QuienesSomos.html">Quiénes somos</a></div>
            <div class="elNav invisibleCelular"><a href="../NuestrosClientes.html">Nuestros clientes</a></div>
            <div class="elNav invisibleCelular"><a href="../NuestrosServicios.html">Nuestros servicios</a></div>
            <div class="elNav invisibleCelular"><a href="../Contacto.html">Contacto</a></div>
            <a onclick="toggleMenu()" id="elNavMenu"><img src="../imagenes/iconos/BotonMenu.png"></a>
        </div>
    </nav>
    <div class="contenido" style="margin-bottom: 30px;">
        <h1 style="padding-top: 15px;">ENKOR-TECH</h1>
        <h2>¿Qué hace ENKOR-TECH?</h2>

        <p>
            ENKOR-TECH es una empresa que realiza servicios a máquinas de refrigeración. Nuestro enfoque es el servicio de mantenimiento preventivo y correctivo a equipos de ciclos térmicos con sus diferentes variantes, tales como: Humedad, Altitud, Choque térmico, entre otros
            <br><br>
            ENKOR-TECH no solo se limita a lo descrito arriba, sino también realiza trabajo en control eléctrico. actualización de controladores de equipos y mejoras a su eficiencia en general.
        </p>
    </div>
    <div id="ListaSeccion">
    <?php
    include('contenido.php');
    $con = mysqli_query($conexion,"SELECT * FROM objetos");
    
    while($consulta = mysqli_fetch_array($con)){
    ?>
    
    <div class="ZonaObjeto">
        <div style="background-image: url(images/<?php echo $consulta['imagen'] ?>)" class="ImagenObjeto" alt="..."></div>
        <h5 class="ObjetoTitulo"><?php echo $consulta['Nombre'] ?></h5>
        <p class="ObjetoDescripcion"><?php echo $consulta['Descripcion'] ?></p>
        <p class="ObjetoCantidad">Cantidad en Stock: <?php echo $consulta['cantidad'] ?></p>
    </div>
    
    <?php
    }
    ?>
    </div>
    <div id="footer">
        <div class="contenido">
            <div>
                <ul class="seccionFooter" style="float: left;">
                    <li style="list-style-type: none;"><b>Contáctanos</b></li>
                    <li>(656) 617-1474</li>
                    <li class=" letraCorreo2">enkor.multiservicios@gmail.com</li>
                    <li>Ciudad Juárez, Chihuahua</li>
                </ul>

                <a href="../Contacto.html" style="text-decoration: none; color: black;"><button id="botonMensaje">Envíanos un mensaje</button></a>

                <ul class="seccionFooter">
                    <li style="list-style-type: none;"><b>Sobre Nosotros</b></li>
                    <li><a href="../QuienesSomos.html">¿Quiénes somos?</a></li>
                    <li><a href="../NuestrosClientes.html">Nuestros clientes</a></li>
                    <li><a href="../NuestrosServicios.html">Nuestros servicios</a></li>
                    <li><a href="../AvisoPrivacidad.html">Aviso de privacidad</a></li>
                </ul>
            </div>
            <p style="text-align: center; position: relative; bottom: -20px; width: 100%; float: left"> 2025 © TODOS LOS DERECHOS RESERVADOS POR ENKOR-TECH</p>
            
            <p style="text-align: center; position: relative; bottom: -20px; width: 100%; float: left; font-size: 8px;">Imágenes del sitio web extraidas de www.vecteezy.com, www.pixabay.com, www.freepik.es y www.flaticon.es</p>
        </div>
    </div>
    
    <script>
        var mapaTextoActual = 0;
        function toggleMenu(){
            var x = document.querySelectorAll(".elNav");
            
            if (x[0].classList.contains('invisibleCelular')) {
                for (var i = 0; i < x.length; i++) {
                    x[i].classList.remove('invisibleCelular');
                }
            } else {
                for (var i = 0; i < x.length; i++) {
                    x[i].classList.add('invisibleCelular');
                }
            }
        }
        
        function showMapa(){
            var x = document.getElementById("zonaMapaShow");
            var y = document.getElementById("zonaMapaHide");
            var z = document.getElementById("cuadroTextoMapa");
	    var w = document.getElementById("contenedorMapaDots");
            
            if (x.classList.contains('esconderZona')) {
                x.classList.remove('esconderZona');
                x.classList.add('mostrandoZona');
		        w.classList.remove('contenedorDotsEscondido');
                w.classList.add('contenedorDotsMostrado');
		        z.classList.add('mostrarTextoMapa');
                z.classList.remove('esconderTextoMapa');
                mostrarTexto(10);
            } else {
                x.classList.add('esconderZona');
                x.classList.remove('mostrandoZona');
		w.classList.remove('contenedorDotsMostrado');
                w.classList.add('contenedorDotsEscondido');
                mapaTextoActual = 0;
                z.classList.remove('mostrarTextoMapa');
                z.classList.add('esconderTextoMapa');
            }
            
            if (y.classList.contains('esconderSection')) {
                y.classList.remove('esconderSection');
                y.classList.add('mostrandoSection');
            } else {
                y.classList.add('esconderSection');
                y.classList.remove('mostrandoSection');
            }
        }
        
        function mostrarTexto(n){
            var y1 = document.getElementById("tituloTextoMapa");
            var y2 = document.getElementById("parrafoTextoMapa");
	        var w = document.getElementById("espacioMapaDots");
            let dots = document.getElementsByClassName("mapaDot");
            
            for (i = 0; i < dots.length; i++) {
                if(dots[i].classList.contains('mapaDotActivo')){
                    dots[i].classList.remove('mapaDotActivo');
                }
            }
            
            dots[n - 1].classList.add('mapaDotActivo');
            
            if (n != mapaTextoActual){
                
                switch(n){
                    case 1:
                        y1.innerHTML = "Sonora";
                        y2.innerHTML = "Nuestros clientes:<br><ul><li>Amphenol Optimize</li></ul>";
                        break;
		            case 2:
                        y1.innerHTML = "Baja California";
                        y2.innerHTML = "Nuestros clientes:<br><ul><li>Dialight de México</li><li>Eaton Controls and Power Conversion</li><li>Honeywell Aerospace</li><li>Medtronic</li><li>ICU Medical</li><li>Samsung.</li></ul>";
                        break;
		            case 3:
                        y1.innerHTML = "Coahuila";
                        y2.innerHTML = "Nuestros clientes:<br><ul><li>Saint Gobain</li><li>Motus Integrated Systems</li></ul>";
                        break;
		            case 4:
                        y1.innerHTML = "Tamaulipas";
                        y2.innerHTML = "Nuestros clientes:<br><ul><li>Autoliv</li></ul>";
                        break;
		            case 5:
                        y1.innerHTML = "Querétaro";
                        y2.innerHTML = "Nuestros clientes:<br><ul><li>Autoliv</li></ul>";
                        break;
		            case 6:
                        y1.innerHTML = "Estado de México";
                        y2.innerHTML = "Nuestros clientes:<br><ul><li>Autoliv</li><li>Fresenious</li></ul>";
                        break;
		            case 7:
                        y1.innerHTML = "Nuevo León";
                        y2.innerHTML = "Nuestros clientes:<br><ul><li>Arca-Continental</li><li>Schneider electric</li></ul>";
                        break;
		            case 8:
                        y1.innerHTML = "Jalisco";
                        y2.innerHTML = "Nuestros clientes:<br><ul><li>Sanmina</li></ul>";
                        break;
                    case 9:
                        y1.innerHTML = "Ciudad Juárez";
                        y2.innerHTML = "Empresas locales:<br><ul><li>Marelli Automotive Lighting</li><li>Bosch</li><li>Continental / Vitesco</li><li>Ethicon</li><li>Honeywell</li><li>Flextronics</li><li>TECMA Boyd Corp.</li><li>Keytronic</li><li>Foxconn / Scientific Atlanta</li><li>Nidec</li><li>Neotech / Epi de México</li><li>Delphi / Borgwarner Systems</li><li>Strattec</li><li>Lexmark Internacional</li><li>Keno Industries</li><li>Optron de México</li><li>Kyocera AVX</li><li>Inteva México</li><li>Electrorika</li><li>Industrias Sicomoro</li><li>Intermatic</li><li>Hanon Systems</li><li>BRP</li><li>Phinia</li><li>CBRE</li></ul>";
                        break;
                    default:
                        y1.innerHTML = "Presencia en México";
                        y2.innerHTML = "Nuestro taller y oficinas principales se encuentran en Ciudad Juárez, Chihuahua, los cuales nos permiten atender a clientes localmente, y en la zona norte del país.<br><br>Actualmente contamos con una bodega totalmente equipada en la ciudad de Querétaro y en la ciudad de México, permitiéndonos dar servicio de emergencia a la zona centro y sur del país.";
                        break;
                }
                mapaTextoActual = n;
            } else{
                /*mapaTextoActual = 0;*/
            }
            
        }
        
    </script>
</body>

</html>